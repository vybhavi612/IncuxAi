import { Router } from 'express';
import { protect } from '../middleware/authMiddleware';
import {
  getWorkspaceTasks,
  createTask,
  updateTask,
  deleteTask,
} from '../controllers/taskController';

const router = Router();

// Protect all routes
router.use(protect);

router.route('/workspace/:teamId')
  .get(getWorkspaceTasks)
  .post(createTask);

router.route('/:id')
  .patch(updateTask)
  .delete(deleteTask);

export default router;
