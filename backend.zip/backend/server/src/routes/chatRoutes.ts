import { Router } from 'express';
import {
  getChannels,
  createChannel,
  getMessages,
  editMessage,
  deleteMessage,
  pinMessage,
  uploadFile,
} from '../controllers/chatController';
import { protect } from '../middleware/authMiddleware';
import { chatUploadMiddleware } from '../services/uploadService';

const router = Router();

// Protect all chat routes
router.use(protect);

router.route('/channels')
  .get(getChannels)
  .post(createChannel);

router.get('/messages/:chatId', getMessages);

// Edit, Delete, Pin Message routes
router.patch('/messages/:messageId', editMessage);
router.delete('/messages/:messageId', deleteMessage);
router.patch('/messages/:messageId/pin', pinMessage);

// File Upload endpoint
router.post('/upload-file', chatUploadMiddleware.single('file'), uploadFile);

export default router;
