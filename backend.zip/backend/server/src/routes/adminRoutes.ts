import { Router } from 'express';
import { protect } from '../middleware/authMiddleware';
import {
  checkAdmin,
  getAdminMetrics,
  getUsersList,
  updateUserStatus,
  getActivityLogs,
} from '../controllers/adminController';

const router = Router();

// Protect all routes with auth & admin status check
router.use(protect);
router.use(checkAdmin);

router.get('/metrics', getAdminMetrics);
router.get('/users', getUsersList);
router.patch('/users/:id', updateUserStatus);
router.get('/logs', getActivityLogs);

export default router;
