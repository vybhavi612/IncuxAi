import { Router } from 'express';
import { protect } from '../middleware/authMiddleware';
import {
  getMyNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
} from '../controllers/notificationController';

const router = Router();

// Protect all routes
router.use(protect);

router.route('/')
  .get(getMyNotifications)
  .patch(markAllNotificationsRead);

router.route('/:id')
  .patch(markNotificationRead)
  .delete(deleteNotification);

export default router;
