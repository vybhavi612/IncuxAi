import { Router } from 'express';
import { protect } from '../middleware/authMiddleware';
import {
  getMyCalendarMeetings,
  createCalendarMeeting,
  deleteCalendarMeeting,
} from '../controllers/calendarController';

const router = Router();

// Protect all routes
router.use(protect);

router.route('/')
  .get(getMyCalendarMeetings)
  .post(createCalendarMeeting);

router.route('/:id')
  .delete(deleteCalendarMeeting);

export default router;
