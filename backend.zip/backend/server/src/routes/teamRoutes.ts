import { Router } from 'express';
import {
  getTeams,
  createTeam,
  inviteMember,
  updateMemberRole,
  removeMember,
  deleteTeam,
} from '../controllers/teamController';
import { protect } from '../middleware/authMiddleware';

const router = Router();

// Protect all team/workspace routes
router.use(protect);

router.route('/')
  .get(getTeams)
  .post(createTeam);

router.post('/:teamId/invite', inviteMember);
router.patch('/:teamId/members/:memberId', updateMemberRole);
router.delete('/:teamId/members/:memberId', removeMember);
router.delete('/:teamId', deleteTeam);

export default router;
