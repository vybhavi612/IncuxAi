import express from 'express';
import { globalSearch, getFiles } from '../controllers/searchController';
import { protect } from '../middleware/authMiddleware';

const router = express.Router();

// All search/files routes are protected
router.use(protect);

router.get('/', globalSearch);
router.get('/files', getFiles);

export default router;
