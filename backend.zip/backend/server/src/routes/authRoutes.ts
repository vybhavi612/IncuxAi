import { Router } from 'express';
import {
  register,
  login,
  logout,
  getMe,
  updateMe,
  verifyEmail,
  refreshToken,
  forgotPassword,
  resetPassword,
  googleLogin,
  changePassword,
  uploadAvatar,
} from '../controllers/authController';
import { protect } from '../middleware/authMiddleware';
import { uploadMiddleware } from '../services/uploadService';
import {
  validateRegister,
  validateLogin,
  validateVerifyEmail,
  validateForgotPassword,
  validateResetPassword,
  validateChangePassword,
  validateUpdateProfile,
} from '../middleware/validationMiddleware';

const router = Router();

// Public routes
router.post('/register', validateRegister, register);
router.post('/login', validateLogin, login);
router.post('/verify-email', validateVerifyEmail, verifyEmail);
router.post('/refresh-token', refreshToken);
router.post('/forgot-password', validateForgotPassword, forgotPassword);
router.post('/reset-password/:token', validateResetPassword, resetPassword);
router.post('/google-login', googleLogin);

// Protected routes (require JWT)
router.use(protect);
router.post('/logout', logout);
router.get('/me', getMe);
router.patch('/update-me', validateUpdateProfile, updateMe);
router.patch('/change-password', validateChangePassword, changePassword);
router.post('/upload-avatar', uploadMiddleware.single('avatar'), uploadAvatar);

export default router;
