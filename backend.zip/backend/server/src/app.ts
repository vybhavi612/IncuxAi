import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import { globalErrorHandler } from './middleware/errorMiddleware';
import { AppError } from './utils/errorHandler';
import connectDB from './config/db';
import authRouter from './routes/authRoutes';
import chatRouter from './routes/chatRoutes';
import dashboardRouter from './routes/dashboardRoutes';
import teamRouter from './routes/teamRoutes';
import searchRouter from './routes/searchRoutes';
import calendarRouter from './routes/calendarRoutes';
import notificationRouter from './routes/notificationRoutes';
import taskRouter from './routes/taskRoutes';
import adminRouter from './routes/adminRoutes';

// Load environment variables
dotenv.config();

const app = express();

// 1. GLOBAL MIDDLEWARES

// Secure HTTP headers with custom Content Security Policy (CSP) for development/live websocket/fonts support
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https://images.unsplash.com"],
        connectSrc: ["'self'", "ws://localhost:5000", "http://localhost:5000", "ws://localhost:5173", "wss:", "ws:"],
      },
    },
  })
);

// Development logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Rate limiting to prevent brute-force / DDoS attacks
const limiter = rateLimit({
  max: 100, // Limit each IP to 100 requests per windowMs
  windowMs: 15 * 60 * 100, // 15 minutes
  message: 'Too many requests from this IP, please try again in 15 minutes!',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', limiter);

// CORS configuration
const allowedOrigins = [
  process.env.CLIENT_URL || 'http://localhost:5173',
  'http://localhost:5000',
  'http://127.0.0.1:5000'
];
app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like mobile apps or curl)
      if (!origin || allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

// Body parser, reading data from body into req.body
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

// Connect to database
connectDB();

// 2. ROUTES
app.use('/api/auth', authRouter);
app.use('/api/chat', chatRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/teams', teamRouter);
app.use('/api/search', searchRouter);
app.use('/api/calendar', calendarRouter);
app.use('/api/notifications', notificationRouter);
app.use('/api/tasks', taskRouter);
app.use('/api/admin', adminRouter);

app.get('/api/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'success',
    message: 'Server is healthy and running!',
    timestamp: new Date().toISOString(),
  });
});

// Serve client static files
const clientBuildPath = path.resolve(__dirname, '../../client/dist');
app.use(express.static(clientBuildPath));

// Handle all SPA routing: serve index.html for non-API routes
app.get('*', (req: Request, res: Response, next: NextFunction) => {
  if (req.originalUrl.startsWith('/api')) {
    return next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
  }
  res.sendFile(path.join(clientBuildPath, 'index.html'));
});

// 3. GLOBAL ERROR MIDDLEWARE
app.use(globalErrorHandler);

export default app;
