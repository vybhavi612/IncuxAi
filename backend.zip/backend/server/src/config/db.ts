import mongoose from 'mongoose';

export const connectDB = async (): Promise<boolean> => {
  const mongoURI = process.env.MONGO_URI || 'mongodb://localhost:27017/video-collab-platform';

  try {
    // Set strictQuery for Mongoose 8
    mongoose.set('strictQuery', true);
    
    console.log(`🔌 Attempting MongoDB connection to: ${mongoURI}`);
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000, // Timeout after 5s instead of 30s
    });

    console.log('✅ MongoDB connected successfully');
    return true;
  } catch (error: any) {
    console.error('⚠️ MongoDB Connection Failed!');
    console.error(`Reason: ${error.message}`);
    console.warn('💡 Tip: Start your local MongoDB database service (e.g. run "mongod") to enable persistent data.');
    console.warn('🚀 The server will continue running in standard memory/signaling mode.');
    return false;
  }
};

export default connectDB;
