import multer from 'multer';
import { v2 as cloudinary } from 'cloudinary';
import { isCloudinaryReady } from '../config/cloudinary';

// Setup multer memory storage (stores file as a buffer in memory)
const storage = multer.memoryStorage();

export const uploadMiddleware = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // limit size to 5MB
  },
  fileFilter: (_req, file, cb) => {
    // Only accept image files for avatar
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!') as any, false);
    }
  },
});

/**
 * Upload a file buffer to Cloudinary (or fallback to Base64 data URI if unconfigured)
 */
export const uploadImageToCloudinary = async (
  fileBuffer: Buffer,
  folder: string = 'avatars',
  fileName?: string
): Promise<string> => {
  if (!isCloudinaryReady) {
    // Fallback: convert to base64 Data URI for visual testing and return it
    const base64Data = fileBuffer.toString('base64');
    const mimeType = fileName && fileName.endsWith('.mp3') ? 'audio/mp3' : 'image/png';
    return `data:${mimeType};base64,${base64Data}`;
  }

  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        public_id: fileName,
        overwrite: true,
        resource_type: 'auto', // Auto detect type (image, video, raw file, etc.)
      },
      (error, result) => {
        if (error) {
          console.error('Cloudinary upload error:', error);
          reject(new Error('Cloudinary upload failed'));
        } else {
          resolve(result?.secure_url || '');
        }
      }
    );

    uploadStream.end(fileBuffer);
  });
};

export const chatUploadMiddleware = multer({
  storage,
  limits: {
    fileSize: 15 * 1024 * 1024, // 15MB limit for chat attachments
  },
  // Allow all file types in chat
});
