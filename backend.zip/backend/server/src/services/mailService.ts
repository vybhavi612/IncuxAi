import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Create transporter
const createTransporter = () => {
  const host = process.env.EMAIL_HOST;
  const port = parseInt(process.env.EMAIL_PORT || '587');
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;

  if (!host || !user || !pass) {
    console.warn('⚠️ SMTP Email service is unconfigured. Emails will be logged to the console for testing.');
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    auth: {
      user,
      pass,
    },
  });
};

const transporter = createTransporter();

interface MailOptions {
  to: string;
  subject: string;
  html: string;
}

export const sendEmail = async (options: MailOptions): Promise<boolean> => {
  const from = process.env.EMAIL_FROM || 'no-reply@collabhub.com';

  if (!transporter) {
    console.log('\n=================== MOCK EMAIL SENT ===================');
    console.log(`To:      ${options.to}`);
    console.log(`Subject: ${options.subject}`);
    console.log(`Body:\n${options.html.replace(/<[^>]*>/g, '')}`); // Strip simple HTML tags for console readability
    console.log('=======================================================\n');
    return true;
  }

  try {
    await transporter.sendMail({
      from,
      to: options.to,
      subject: options.subject,
      html: options.html,
    });
    return true;
  } catch (error) {
    console.error('📧 Error sending email:', error);
    return false;
  }
};

/**
 * Send email verification code
 */
export const sendVerificationEmail = async (email: string, code: string): Promise<boolean> => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background-color: #f8fafc;">
      <h2 style="color: #4f46e5; text-align: center;">Verify Your Email Address</h2>
      <p>Hello,</p>
      <p>Thank you for registering at CollabHub! Please verify your email by using the registration verification code below:</p>
      <div style="text-align: center; margin: 30px 0;">
        <span style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #1e1b4b; background-color: #e0e7ff; padding: 10px 24px; border-radius: 8px; border: 1px dashed #4f46e5;">${code}</span>
      </div>
      <p>This code is valid for 1 hour. If you didn't create an account, please ignore this email.</p>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin-top: 30px;" />
      <p style="font-size: 11px; color: #64748b; text-align: center;">CollabHub Inc., Real-Time Video Collaboration Platform</p>
    </div>
  `;
  return await sendEmail({
    to: email,
    subject: 'CollabHub Email Verification',
    html,
  });
};

/**
 * Send password reset link
 */
export const sendPasswordResetEmail = async (email: string, resetUrl: string): Promise<boolean> => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background-color: #f8fafc;">
      <h2 style="color: #4f46e5; text-align: center;">Reset Your Password</h2>
      <p>Hello,</p>
      <p>We received a request to reset the password for your CollabHub account. Click the button below to set a new password:</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${resetUrl}" style="background-color: #4f46e5; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">Reset Password</a>
      </div>
      <p>If you cannot click the button, copy and paste this link in your browser:</p>
      <p style="word-break: break-all; color: #4f46e5;"><a href="${resetUrl}">${resetUrl}</a></p>
      <p>This link is valid for 1 hour. If you did not request a password reset, please ignore this email.</p>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin-top: 30px;" />
      <p style="font-size: 11px; color: #64748b; text-align: center;">CollabHub Inc., Real-Time Video Collaboration Platform</p>
    </div>
  `;
  return await sendEmail({
    to: email,
    subject: 'CollabHub Password Reset',
    html,
  });
};
