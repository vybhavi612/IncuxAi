import { Server, Socket } from 'socket.io';
import mongoose from 'mongoose';
import { Message } from '../models/Message';

export const initSocket = (httpServer: any) => {
  const io = new Server(httpServer, {
    cors: {
      origin: [process.env.CLIENT_URL || 'http://localhost:5173'],
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  console.log('⚡ Socket.io signaling server initialized');

  io.on('connection', (socket: Socket) => {
    console.log(`🔌 Socket connected: ${socket.id}`);

    // 1. JOIN ROOM / CHANNEL
    socket.on('join-room', (data: { roomId: string; userId: string; userName: string; userAvatar?: string }) => {
      const { roomId, userId, userName, userAvatar } = data;
      socket.join(roomId);
      console.log(`👤 User ${userName} (${userId}) joined room ${roomId}`);

      // Broadcast to other users in the room
      socket.to(roomId).emit('participant-joined', {
        id: userId,
        name: userName,
        avatar: userAvatar,
        videoEnabled: true,
        audioEnabled: true,
        screenShareEnabled: false,
        handRaised: false,
        isLocal: false,
        socketId: socket.id,
      });

      // Send confirmation back
      socket.emit('joined-room-success', { roomId });
    });

    // 2. WEBRTC SIGNALING (OFFER, ANSWER, ICE CANDIDATES)
    // Forward RTC offers
    socket.on('send-offer', (data: { offer: any; roomId: string; toSocketId?: string }) => {
      const { offer, roomId, toSocketId } = data;
      if (toSocketId) {
        socket.to(toSocketId).emit('receive-offer', { offer, fromSocketId: socket.id });
      } else {
        socket.to(roomId).emit('receive-offer', { offer, fromSocketId: socket.id });
      }
    });

    // Forward RTC answers
    socket.on('send-answer', (data: { answer: any; toSocketId: string }) => {
      const { answer, toSocketId } = data;
      socket.to(toSocketId).emit('receive-answer', { answer, fromSocketId: socket.id });
    });

    // Forward ICE candidates
    socket.on('send-ice-candidate', (data: { candidate: any; roomId: string; toSocketId?: string }) => {
      const { candidate, roomId, toSocketId } = data;
      if (toSocketId) {
        socket.to(toSocketId).emit('receive-ice-candidate', { candidate, fromSocketId: socket.id });
      } else {
        socket.to(roomId).emit('receive-ice-candidate', { candidate, fromSocketId: socket.id });
      }
    });

    // 3. CHAT MESSAGES RELAY
    socket.on('send-chat-message', async (data: {
      chatId: string;
      senderId: string;
      senderName: string;
      senderAvatar?: string;
      content: string;
      type: 'text' | 'code' | 'file';
      codeLanguage?: string;
      codeSnippet?: string;
      fileUrl?: string;
      fileName?: string;
      fileSize?: string;
    }) => {
      const { chatId, senderId, senderName, senderAvatar, content, type, codeLanguage, codeSnippet, fileUrl, fileName, fileSize } = data;

      const messagePayload = {
        id: `msg_${Date.now()}`,
        chatId,
        sender: { id: senderId, name: senderName, avatar: senderAvatar },
        content,
        timestamp: new Date().toISOString(),
        type,
        codeLanguage,
        codeSnippet,
        fileUrl,
        fileName,
        fileSize,
      };

      // Broadcast message to channel/DM room members
      io.to(chatId).emit('receive-chat-message', messagePayload);

      // Attempt to save to database if MongoDB is connected
      if (mongoose.connection.readyState === 1) {
        try {
          await Message.create({
            chatId,
            sender: new mongoose.Types.ObjectId(senderId),
            content,
            type,
            codeLanguage,
            codeSnippet,
            fileUrl,
            fileName,
            fileSize,
          });
        } catch (dbErr) {
          console.error('⚠️ Failed to persist socket message to DB:', dbErr);
        }
      }
    });

    // 4. HAND RAISE & AUDIO/VIDEO STATUS RELAYS
    socket.on('toggle-status', (data: { roomId: string; userId: string; statusType: 'audio' | 'video' | 'hand' | 'share'; enabled: boolean }) => {
      const { roomId, userId, statusType, enabled } = data;
      socket.to(roomId).emit('participant-status-updated', { userId, statusType, enabled });
    });

    // 5. LEAVE ROOM / DISCONNECT
    socket.on('leave-room', (data: { roomId: string; userId: string }) => {
      const { roomId, userId } = data;
      socket.leave(roomId);
      socket.to(roomId).emit('participant-left', { id: userId, socketId: socket.id });
      console.log(`👤 User ${userId} left room ${roomId}`);
    });

    // 6. REACTION RELAY
    socket.on('send-reaction', (data: { roomId: string; messageId: string; emoji: string; userId: string }) => {
      socket.to(data.roomId).emit('receive-reaction', data);
    });

    // 7. REPLY RELAY
    socket.on('send-reply', (data: { roomId: string; parentId: string; content: string; sender: any }) => {
      socket.to(data.roomId).emit('receive-reply', data);
    });

    // 7.0 MEETING CHAT RELAY
    socket.on('send-meeting-message', (data: { roomId: string; sender: string; content: string; time: string }) => {
      socket.to(data.roomId).emit('receive-meeting-message', data);
    });

    // 7.1 TYPING STATUS RELAYS
    socket.on('typing', (data: { roomId: string; userId: string; userName: string }) => {
      socket.to(data.roomId).emit('user-typing', data);
    });

    socket.on('stop-typing', (data: { roomId: string; userId: string }) => {
      socket.to(data.roomId).emit('user-stop-typing', data);
    });

    // 7.2 EDIT/DELETE RELAYS
    socket.on('edit-message', (data: { roomId: string; messageId: string; content: string }) => {
      socket.to(data.roomId).emit('receive-edit-message', data);
    });

    socket.on('delete-message', (data: { roomId: string; messageId: string }) => {
      socket.to(data.roomId).emit('receive-delete-message', data);
    });

    socket.on('pin-message', (data: { roomId: string; messageId: string; isPinned: boolean }) => {
      socket.to(data.roomId).emit('receive-pin-message', data);
    });

    // 8. WHITEBOARD DRAW DATA RELAY
    socket.on('draw-data', (data: { roomId: string; drawingData: any }) => {
      socket.to(data.roomId).emit('receive-draw-data', data.drawingData);
    });

    socket.on('disconnect', () => {
      console.log(`🔌 Socket disconnected: ${socket.id}`);
      // Broadcast disconnect to all rooms
      io.emit('participant-disconnected', { socketId: socket.id });
    });
  });

  return io;
};
