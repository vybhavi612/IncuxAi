import { Request, Response, NextFunction } from 'express';
import { body, validationResult, ValidationChain } from 'express-validator';
import { AppError } from '../utils/errorHandler';

// Helper middleware to handle the validation result
export const validateResult = (req: Request, _res: Response, next: NextFunction) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorMsg = errors.array().map(err => err.msg).join(', ');
    return next(new AppError(errorMsg, 400));
  }
  next();
};

// Validator definitions
export const validateRegister: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Please provide a name')
    .isLength({ min: 2 })
    .withMessage('Name must be at least 2 characters'),
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Please provide an email')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Please provide a password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  validateResult,
];

export const validateLogin: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Please provide an email')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Please provide a password'),
  validateResult,
];

export const validateVerifyEmail: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Provide a valid email address')
    .normalizeEmail(),
  body('code')
    .trim()
    .notEmpty()
    .withMessage('Verification code is required')
    .isLength({ min: 6, max: 6 })
    .withMessage('Verification code must be exactly 6 characters'),
  validateResult,
];

export const validateForgotPassword: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Provide a valid email address')
    .normalizeEmail(),
  validateResult,
];

export const validateResetPassword: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('password')
    .notEmpty()
    .withMessage('New password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  validateResult,
];

export const validateChangePassword: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('oldPassword')
    .notEmpty()
    .withMessage('Current password is required'),
  body('newPassword')
    .notEmpty()
    .withMessage('New password is required')
    .isLength({ min: 6 })
    .withMessage('New password must be at least 6 characters')
    .custom((value, { req }) => {
      if (value === req.body.oldPassword) {
        throw new Error('New password cannot be the same as old password');
      }
      return true;
    }),
  validateResult,
];

export const validateUpdateProfile: (ValidationChain | ((req: Request, res: Response, next: NextFunction) => void))[] = [
  body('name')
    .optional()
    .trim()
    .isLength({ min: 2 })
    .withMessage('Name must be at least 2 characters'),
  body('customStatus')
    .optional()
    .trim(),
  validateResult,
];
