import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import { User } from '../models/User';
import { AppError } from '../utils/errorHandler';

export const protect = async (req: Request, _res: Response, next: NextFunction) => {
  let token: string | undefined;

  // 1. Get token from authorization headers or cookies
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return next(new AppError('You are not logged in! Please log in to get access.', 401));
  }

  try {
    // 2. Verification of token
    const decoded: any = jwt.verify(token, process.env.JWT_SECRET || 'super_secret_access_token_key_12345!');

    // 3. Check if user still exists (with fallback if MongoDB is offline)
    let currentUser: any;
    if (mongoose.connection.readyState !== 1) {
      currentUser = {
        id: decoded.id,
        _id: decoded.id,
        name: decoded.id === 'u1' ? 'ADMIN' : 'USER',
        email: decoded.id === 'u1' ? 'admin@collabhub.com' : 'user@collabhub.com',
        role: decoded.id === 'u1' ? 'admin' : 'user',
        status: 'active',
      };
    } else {
      currentUser = await User.findById(decoded.id);
      if (!currentUser) {
        return next(new AppError('The user belonging to this token no longer exists.', 401));
      }
      if (currentUser.status === 'suspended') {
        return next(new AppError('Your account has been suspended. Please contact the administrator.', 403));
      }
    }

    // 4. Grant access to protected route (cast req to any to attach user)
    (req as any).user = currentUser;
    next();
  } catch (error: any) {
    return next(new AppError('Invalid token or signature. Please log in again!', 401));
  }
};

// Role authorization check middleware
export const restrictTo = (...roles: string[]) => {
  return (req: Request, _res: Response, next: NextFunction) => {
    const currentUser = (req as any).user;
    if (!currentUser || !roles.includes(currentUser.role)) {
      return next(new AppError('You do not have permission to perform this action', 403));
    }
    next();
  };
};
