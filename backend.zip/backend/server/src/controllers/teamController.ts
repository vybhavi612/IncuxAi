import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Team } from '../models/Team';
import { User } from '../models/User';
import { AppError } from '../utils/errorHandler';

// Mock listings for DB Offline Mode
const mockWorkspaces = [
  {
    id: 'w1',
    name: 'Engineering Workspace',
    description: 'Technical discussions, codebase guidelines, and system architectures',
    members: [
      { user: { id: 'u1', name: 'You', role: 'owner' }, role: 'owner' },
      { user: { id: 'u2', name: 'Sarah Connor' }, role: 'admin' },
      { user: { id: 'u3', name: 'John Doe' }, role: 'member' }
    ]
  },
  {
    id: 'w2',
    name: 'Product & Design',
    description: 'UI/UX mockups, customer flows, and product requirements docs',
    members: [
      { user: { id: 'u1', name: 'You', role: 'member' }, role: 'member' },
      { user: { id: 'u2', name: 'Sarah Connor' }, role: 'owner' }
    ]
  }
];

// 1. GET WORKSPACES
export const getTeams = async (req: Request, res: Response, next: NextFunction) => {
  const currentUserId = (req as any).user._id || (req as any).user.id;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      teams: mockWorkspaces,
    });
  }

  try {
    const teams = await Team.find({
      'members.user': currentUserId
    }).populate('members.user', 'name email avatar');

    res.status(200).json({
      status: 'success',
      teams: teams.length > 0 ? teams : mockWorkspaces,
    });
  } catch (error: any) {
    next(error);
  }
};

// 2. CREATE WORKSPACE
export const createTeam = async (req: Request, res: Response, next: NextFunction) => {
  const { name, description } = req.body;
  const currentUserId = (req as any).user._id || (req as any).user.id;

  if (!name) {
    return next(new AppError('Please provide a workspace name', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    const mockW = {
      id: `w_${Date.now()}`,
      name,
      description: description || '',
      members: [
        { user: { id: currentUserId, name: (req as any).user.name, avatar: (req as any).user.avatar }, role: 'owner' }
      ]
    };
    return res.status(201).json({
      status: 'success',
      team: mockW,
    });
  }

  try {
    const newTeam = await Team.create({
      name,
      description: description || '',
      members: [{ user: currentUserId, role: 'owner' }],
    });

    const populatedTeam = await newTeam.populate('members.user', 'name email avatar');

    res.status(201).json({
      status: 'success',
      team: populatedTeam,
    });
  } catch (error: any) {
    next(error);
  }
};

// 3. INVITE MEMBER
export const inviteMember = async (req: Request, res: Response, next: NextFunction) => {
  const { teamId } = req.params;
  const { email } = req.body;

  if (!email) {
    return next(new AppError('Please provide email to invite', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      member: {
        user: { id: `u_${Date.now()}`, name: email.split('@')[0], email },
        role: 'member'
      }
    });
  }

  try {
    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    // Verify current user is admin/owner
    const currentUserId = (req as any).user._id || (req as any).user.id;
    const isAuthorized = team.members.some(
      (m) => m.user.toString() === currentUserId.toString() && (m.role === 'owner' || m.role === 'admin')
    );

    if (!isAuthorized) {
      return next(new AppError('You do not have permission to invite members to this workspace', 403));
    }

    // Find user to invite
    const invitedUser = await User.findOne({ email });
    if (!invitedUser) {
      return next(new AppError('User with this email does not exist', 404));
    }

    // Check if already member
    const alreadyMember = team.members.some((m) => m.user.toString() === invitedUser._id.toString());
    if (alreadyMember) {
      return next(new AppError('User is already a member of this workspace', 400));
    }

    team.members.push({ user: invitedUser._id, role: 'member' });
    await team.save();

    res.status(200).json({
      status: 'success',
      member: {
        user: { id: invitedUser._id, name: invitedUser.name, email: invitedUser.email, avatar: invitedUser.avatar },
        role: 'member'
      }
    });
  } catch (error: any) {
    next(error);
  }
};

// 4. UPDATE MEMBER ROLE
export const updateMemberRole = async (req: Request, res: Response, next: NextFunction) => {
  const { teamId, memberId } = req.params;
  const { role } = req.body;

  if (!role || !['admin', 'member'].includes(role)) {
    return next(new AppError('Valid role (admin or member) is required', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      memberId,
      role
    });
  }

  try {
    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    // Current user must be owner or admin
    const currentUserId = (req as any).user._id || (req as any).user.id;
    const isAuthorized = team.members.some(
      (m) => m.user.toString() === currentUserId.toString() && (m.role === 'owner' || m.role === 'admin')
    );

    if (!isAuthorized) {
      return next(new AppError('Unauthorized to modify roles in this workspace', 403));
    }

    const member = team.members.find((m) => m.user.toString() === memberId.toString());
    if (!member) {
      return next(new AppError('Member not found in workspace', 404));
    }

    if (member.role === 'owner') {
      return next(new AppError('Cannot demote the workspace owner', 400));
    }

    member.role = role;
    await team.save();

    res.status(200).json({
      status: 'success',
      memberId,
      role
    });
  } catch (error: any) {
    next(error);
  }
};

// 5. REMOVE MEMBER
export const removeMember = async (req: Request, res: Response, next: NextFunction) => {
  const { teamId, memberId } = req.params;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      memberId
    });
  }

  try {
    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    // Current user must be owner or admin
    const currentUserId = (req as any).user._id || (req as any).user.id;
    const isAuthorized = team.members.some(
      (m) => m.user.toString() === currentUserId.toString() && (m.role === 'owner' || m.role === 'admin')
    );

    if (!isAuthorized) {
      return next(new AppError('Unauthorized to remove members from this workspace', 403));
    }

    const member = team.members.find((m) => m.user.toString() === memberId.toString());
    if (!member) {
      return next(new AppError('Member not found', 404));
    }

    if (member.role === 'owner') {
      return next(new AppError('Cannot remove the workspace owner', 400));
    }

    const index = team.members.findIndex((m) => m.user.toString() === memberId.toString());
    if (index > -1) {
      team.members.splice(index, 1);
    }
    await team.save();

    res.status(200).json({
      status: 'success',
      memberId
    });
  } catch (error: any) {
    next(error);
  }
};

// 6. DELETE WORKSPACE
export const deleteTeam = async (req: Request, res: Response, next: NextFunction) => {
  const { teamId } = req.params;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      teamId
    });
  }

  try {
    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    // Check if user is owner
    const currentUserId = (req as any).user._id || (req as any).user.id;
    const isOwner = team.members.some(
      (m) => m.user.toString() === currentUserId.toString() && m.role === 'owner'
    );

    if (!isOwner) {
      return next(new AppError('Only the workspace owner can delete this workspace', 403));
    }

    await Team.findByIdAndDelete(teamId);

    res.status(200).json({
      status: 'success',
      teamId
    });
  } catch (error: any) {
    next(error);
  }
};
