import { Request, Response, NextFunction } from 'express';
import User from '../models/User';
import Meeting from '../models/Meeting';
import Message from '../models/Message';
import Team from '../models/Team';
import ActivityLog from '../models/ActivityLog';
import { AppError } from '../utils/errorHandler';

// Helper middleware to check for admin role
export const checkAdmin = (req: Request, res: Response, next: NextFunction) => {
  if ((req as any).user?.role !== 'admin') {
    return next(new AppError('Only administrators have access to this resource', 403));
  }
  next();
};

// Fetch system analytics metrics
export const getAdminMetrics = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const totalUsers = await User.countDocuments();
    const activeRooms = await Meeting.countDocuments({ status: 'active' });
    const totalTeams = await Team.countDocuments();

    // Messages sent this week
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const weeklyMessages = await Message.countDocuments({ createdAt: { $gte: oneWeekAgo } });

    res.status(200).json({
      status: 'success',
      metrics: {
        totalUsers,
        activeRooms,
        totalTeams,
        weeklyMessages,
      },
    });
  } catch (error) {
    next(error);
  }
};

// List all users in system
export const getUsersList = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const users = await User.find({}, '-password').sort({ createdAt: -1 });

    res.status(200).json({
      status: 'success',
      results: users.length,
      users,
    });
  } catch (error) {
    next(error);
  }
};

// Ban / Suspend or Unsuspend a user
export const updateUserStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const { status, role } = req.body;

    const user = await User.findById(id);
    if (!user) {
      return next(new AppError('User not found', 404));
    }

    // Don't allow changing self status
    if (user._id.toString() === ((req as any).user?.id || (req as any).user?._id).toString()) {
      return next(new AppError('You cannot update your own administrative status', 400));
    }

    if (status !== undefined) {
      user.status = status;
    }
    if (role !== undefined) {
      user.role = role;
    }

    await user.save();

    // Log this action
    await ActivityLog.create({
      user: (req as any).user?.id || (req as any).user?._id,
      action: 'ADMIN_UPDATE_USER',
      details: `Updated user ${user.email} (Status: ${status || 'unchanged'}, Role: ${role || 'unchanged'})`,
      ipAddress: req.ip,
    });

    res.status(200).json({
      status: 'success',
      user,
    });
  } catch (error) {
    next(error);
  }
};

// Fetch recent activity logs
export const getActivityLogs = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const logs = await ActivityLog.find()
      .populate('user', 'name email')
      .sort({ createdAt: -1 })
      .limit(100);

    res.status(200).json({
      status: 'success',
      results: logs.length,
      logs,
    });
  } catch (error) {
    next(error);
  }
};
