import { Request, Response, NextFunction } from 'express';
import Notification from '../models/Notification';
import { AppError } from '../utils/errorHandler';

// Get all notifications for the logged in user
export const getMyNotifications = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = (req as any).user?.id || (req as any).user?._id;
    if (!userId) {
      return next(new AppError('You must be logged in to fetch notifications', 401));
    }

    const notifications = await Notification.find({ recipient: userId })
      .populate('sender', 'name email avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: 'success',
      results: notifications.length,
      notifications,
    });
  } catch (error) {
    next(error);
  }
};

// Mark a single notification as read
export const markNotificationRead = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const notification = await Notification.findById(id);
    if (!notification) {
      return next(new AppError('Notification not found', 404));
    }

    if (notification.recipient.toString() !== userId.toString()) {
      return next(new AppError('Unauthorized', 403));
    }

    notification.isRead = true;
    await notification.save();

    res.status(200).json({
      status: 'success',
      notification,
    });
  } catch (error) {
    next(error);
  }
};

// Mark all user notifications as read
export const markAllNotificationsRead = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = (req as any).user?.id || (req as any).user?._id;
    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    await Notification.updateMany({ recipient: userId, isRead: false }, { isRead: true });

    res.status(200).json({
      status: 'success',
      message: 'All notifications marked as read',
    });
  } catch (error) {
    next(error);
  }
};

// Delete a notification
export const deleteNotification = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const notification = await Notification.findById(id);
    if (!notification) {
      return next(new AppError('Notification not found', 404));
    }

    if (notification.recipient.toString() !== userId.toString()) {
      return next(new AppError('Unauthorized', 403));
    }

    await Notification.findByIdAndDelete(id);

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    next(error);
  }
};
