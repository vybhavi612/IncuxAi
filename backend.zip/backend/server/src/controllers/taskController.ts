import { Request, Response, NextFunction } from 'express';
import Task from '../models/Task';
import Team from '../models/Team';
import { AppError } from '../utils/errorHandler';

// Get all tasks for a specific team/workspace
export const getWorkspaceTasks = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { teamId } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    // Verify workspace exists and user is a member
    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    const isMember = team.members.some(
      (m) => m.user.toString() === userId.toString()
    );
    if (!isMember) {
      return next(new AppError('You do not belong to this workspace', 403));
    }

    const tasks = await Task.find({ team: teamId })
      .populate('assignedTo', 'name email avatar')
      .populate('createdBy', 'name email avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: 'success',
      results: tasks.length,
      tasks,
    });
  } catch (error) {
    next(error);
  }
};

// Create a new task in a workspace
export const createTask = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { teamId } = req.params;
    const { title, description, status, priority, dueDate, assignedTo } = req.body;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const team = await Team.findById(teamId);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    const isMember = team.members.some(
      (m) => m.user.toString() === userId.toString()
    );
    if (!isMember) {
      return next(new AppError('Unauthorized', 403));
    }

    const task = await Task.create({
      title,
      description,
      status: status || 'todo',
      priority: priority || 'medium',
      dueDate: dueDate || null,
      assignedTo: assignedTo || null,
      team: teamId,
      createdBy: userId,
    });

    const populatedTask = await Task.findById(task._id)
      .populate('assignedTo', 'name email avatar')
      .populate('createdBy', 'name email avatar');

    res.status(201).json({
      status: 'success',
      task: populatedTask,
    });
  } catch (error) {
    next(error);
  }
};

// Update an existing task
export const updateTask = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const task = await Task.findById(id);
    if (!task) {
      return next(new AppError('Task not found', 404));
    }

    // Verify workspace membership
    const team = await Team.findById(task.team);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    const isMember = team.members.some(
      (m) => m.user.toString() === userId.toString()
    );
    if (!isMember) {
      return next(new AppError('Unauthorized', 403));
    }

    // Update fields allowed to change
    const allowedFields = ['title', 'description', 'status', 'priority', 'dueDate', 'assignedTo'];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        (task as any)[field] = req.body[field];
      }
    });

    await task.save();

    const populatedTask = await Task.findById(task._id)
      .populate('assignedTo', 'name email avatar')
      .populate('createdBy', 'name email avatar');

    res.status(200).json({
      status: 'success',
      task: populatedTask,
    });
  } catch (error) {
    next(error);
  }
};

// Delete a task
export const deleteTask = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const task = await Task.findById(id);
    if (!task) {
      return next(new AppError('Task not found', 404));
    }

    // Verify workspace membership
    const team = await Team.findById(task.team);
    if (!team) {
      return next(new AppError('Workspace not found', 404));
    }

    const isMember = team.members.some(
      (m) => m.user.toString() === userId.toString()
    );
    if (!isMember) {
      return next(new AppError('Unauthorized', 403));
    }

    await Task.findByIdAndDelete(id);

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    next(error);
  }
};
