import { Request, Response, NextFunction } from 'express';
import Message from '../models/Message';
import Channel from '../models/Channel';
import User from '../models/User';

// Global search for messages, channels, members, files
export const globalSearch = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { query } = req.query;
    if (!query || typeof query !== 'string') {
      return res.status(200).json({
        status: 'success',
        results: { channels: [], members: [], messages: [], files: [] }
      });
    }

    const regex = new RegExp(query, 'i');

    // 1. Search Channels
    const channels = await Channel.find({
      $or: [{ name: regex }, { description: regex }]
    }).limit(15);

    // 2. Search Members
    const members = await User.find({
      $or: [{ name: regex }, { email: regex }]
    }).select('name email avatar').limit(15);

    // 3. Search Messages
    const messages = await Message.find({
      type: 'text',
      content: regex
    }).populate('sender', 'name avatar').limit(20);

    // 4. Search Files
    const files = await Message.find({
      type: 'file',
      $or: [{ fileName: regex }, { content: regex }]
    }).populate('sender', 'name avatar').limit(20);

    res.status(200).json({
      status: 'success',
      results: {
        channels,
        members,
        messages,
        files
      }
    });
  } catch (error) {
    next(error);
  }
};

// Retrieve shared files library with category filtering
export const getFiles = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { category } = req.query;
    const filter: any = { type: 'file' };

    if (category && category !== 'all') {
      if (category === 'images') {
        filter.mimeType = { $regex: '^image/', $options: 'i' };
      } else if (category === 'docs') {
        filter.mimeType = { $regex: 'pdf|doc|docx|txt|xls|xlsx|ppt|pptx', $options: 'i' };
      } else if (category === 'media') {
        filter.mimeType = { $regex: '^(audio|video)/', $options: 'i' };
      } else if (category === 'others') {
        filter.mimeType = { 
          $not: { 
            $regex: '^(image|audio|video)/|pdf|doc|docx|txt|xls|xlsx|ppt|pptx', 
            $options: 'i' 
          } 
        };
      }
    }

    const files = await Message.find(filter)
      .populate('sender', 'name email avatar')
      .sort({ timestamp: -1 });

    res.status(200).json({
      status: 'success',
      files
    });
  } catch (error) {
    next(error);
  }
};
