import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import crypto from 'crypto';
import { User } from '../models/User';
import { AppError } from '../utils/errorHandler';
import { sendVerificationEmail, sendPasswordResetEmail } from '../services/mailService';
import { uploadImageToCloudinary } from '../services/uploadService';

// JWT Configuration helpers
const signToken = (id: string): string => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'super_secret_access_token_key_12345!', {
    expiresIn: (process.env.JWT_EXPIRE || '15m') as any,
  });
};

const signRefreshToken = (id: string): string => {
  return jwt.sign({ id }, process.env.JWT_REFRESH_SECRET || 'super_secret_refresh_token_key_67890!', {
    expiresIn: (process.env.JWT_REFRESH_EXPIRE || '7d') as any,
  });
};

const createSendToken = (user: any, statusCode: number, res: Response) => {
  const token = signToken(user._id || user.id);
  const refreshToken = signRefreshToken(user._id || user.id);

  // Update refreshToken in DB if DB is online and user has a save method
  if (mongoose.connection.readyState === 1 && typeof user.save === 'function') {
    user.refreshToken = refreshToken;
    user.save({ validateBeforeSave: false }).catch((err: any) => {
      console.error('Failed to save refresh token to user:', err);
    });
  }

  // Set Cookie options
  const cookieOptions = {
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
  };

  res.cookie('token', token, cookieOptions);
  res.cookie('refreshToken', refreshToken, { ...cookieOptions, path: '/api/auth/refresh-token' });

  // Remove sensitive fields
  user.password = undefined;
  user.refreshToken = undefined;
  user.verificationToken = undefined;
  user.verificationTokenExpires = undefined;
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;

  res.status(statusCode).json({
    status: 'success',
    token,
    refreshToken,
    user,
  });
};

// 1. REGISTER
export const register = async (req: Request, res: Response, next: NextFunction) => {
  const { name, email, password } = req.body;

  // Fallback if MongoDB is offline
  if (mongoose.connection.readyState !== 1) {
    console.log('⚠️ MongoDB offline: registering mock user session');
    const mockUser = {
      id: `u_${Date.now()}`,
      name,
      email,
      role: email.includes('admin') ? 'admin' : 'user',
      status: 'active',
      isVerified: true,
    };
    return createSendToken(mockUser, 201, res);
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return next(new AppError('Email is already registered', 400));
    }

    // Generate a 6-digit email verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    const verificationTokenExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    // Send verification email
    const emailSent = await sendVerificationEmail(email, verificationCode);
    if (!emailSent) {
      return next(new AppError('Failed to send verification email. Try again.', 500));
    }

    // Hash the code to save in the database for security
    const hashedVerificationCode = crypto.createHash('sha256').update(verificationCode).digest('hex');
    const role = email.includes('admin') ? 'admin' : 'user';

    const newUser = await User.create({
      name,
      email,
      password,
      role,
      verificationToken: hashedVerificationCode,
      verificationTokenExpires,
      isVerified: false,
    });

    res.status(201).json({
      status: 'success',
      message: 'Registration successful! A verification code has been sent to your email.',
      email: newUser.email,
    });
  } catch (error: any) {
    next(error);
  }
};

// 2. EMAIL VERIFICATION
export const verifyEmail = async (req: Request, res: Response, next: NextFunction) => {
  const { email, code } = req.body;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: 'Email verified successfully (Mock Mode)',
      token: 'jwt_mock_token_12345',
      user: {
        id: 'u1',
        name: 'MOCK USER',
        email,
        role: 'user',
        status: 'active',
      },
    });
  }

  try {
    const hashedCode = crypto.createHash('sha256').update(code).digest('hex');

    const user = await User.findOne({
      email,
      verificationToken: hashedCode,
      verificationTokenExpires: { $gt: new Date() },
    });

    if (!user) {
      return next(new AppError('Verification code is invalid or has expired', 400));
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpires = undefined;
    await user.save({ validateBeforeSave: false });

    createSendToken(user, 200, res);
  } catch (error: any) {
    next(error);
  }
};

// 3. LOGIN
export const login = async (req: Request, res: Response, next: NextFunction) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return next(new AppError('Please provide email and password', 400));
  }

  // Fallback if MongoDB is offline
  if (mongoose.connection.readyState !== 1) {
    console.log('⚠️ MongoDB offline: executing mock login bypass');
    const role = email.includes('admin') ? 'admin' : 'user';
    const mockUser = {
      id: 'u1',
      name: email.split('@')[0].toUpperCase(),
      email,
      role,
      status: 'active',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    };
    return createSendToken(mockUser, 200, res);
  }

  try {
    const user = await User.findOne({ email }).select('+password');

    if (!user || !(await (user as any).comparePassword(password))) {
      return next(new AppError('Incorrect email or password', 401));
    }

    if (user.status === 'suspended') {
      return next(new AppError('Your account has been suspended', 403));
    }

    if (!user.isVerified) {
      // Re-trigger verification code send if they are not verified yet
      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const verificationTokenExpires = new Date(Date.now() + 60 * 60 * 1000);

      await sendVerificationEmail(email, verificationCode);
      const hashedCode = crypto.createHash('sha256').update(verificationCode).digest('hex');

      user.verificationToken = hashedCode;
      user.verificationTokenExpires = verificationTokenExpires;
      await user.save({ validateBeforeSave: false });

      return res.status(403).json({
        status: 'fail',
        message: 'Your email address is not verified. A new code has been sent.',
        emailNotVerified: true,
        email,
      });
    }

    createSendToken(user, 200, res);
  } catch (error: any) {
    next(error);
  }
};

// 4. REFRESH TOKEN
export const refreshToken = async (req: Request, res: Response, next: NextFunction) => {
  let refToken = req.body.refreshToken || req.cookies.refreshToken;

  if (!refToken) {
    return next(new AppError('Refresh token is required', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    // Return mock fresh token details
    return res.status(200).json({
      status: 'success',
      token: 'jwt_mock_token_refreshed_12345',
      refreshToken: refToken,
    });
  }

  try {
    const decoded: any = jwt.verify(refToken, process.env.JWT_REFRESH_SECRET || 'super_secret_refresh_token_key_67890!');

    const user = await User.findOne({ _id: decoded.id, refreshToken: refToken });
    if (!user) {
      return next(new AppError('Token owner no longer exists or token has been rotated', 401));
    }

    const newAccessToken = signToken(user.id);
    res.status(200).json({
      status: 'success',
      token: newAccessToken,
    });
  } catch (error) {
    return next(new AppError('Invalid or expired refresh token. Please sign in again.', 401));
  }
};

// 5. FORGOT PASSWORD
export const forgotPassword = async (req: Request, res: Response, next: NextFunction) => {
  const { email } = req.body;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: 'Password reset link sent to your email (Mock Mode)',
    });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return next(new AppError('There is no user registered with this email address.', 404));
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    const resetExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    user.passwordResetToken = hashedResetToken;
    user.passwordResetExpires = resetExpires;
    await user.save({ validateBeforeSave: false });

    // Send email
    const resetUrl = `${req.protocol}://${req.get('host')}/reset-password/${resetToken}`;
    // For custom React clients:
    const clientResetUrl = `${process.env.CLIENT_URL || 'http://localhost:5173'}/reset-password/${resetToken}`;

    const sent = await sendPasswordResetEmail(email, clientResetUrl);
    if (!sent) {
      user.passwordResetToken = undefined;
      user.passwordResetExpires = undefined;
      await user.save({ validateBeforeSave: false });
      return next(new AppError('There was an error sending the reset email. Try again later.', 500));
    }

    res.status(200).json({
      status: 'success',
      message: 'Password reset link has been sent to your email.',
    });
  } catch (error) {
    next(error);
  }
};

// 6. RESET PASSWORD
export const resetPassword = async (req: Request, res: Response, next: NextFunction) => {
  const { token } = req.params;
  const { password } = req.body;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: 'Password updated successfully (Mock Mode)',
    });
  }

  try {
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: new Date() },
    });

    if (!user) {
      return next(new AppError('Password reset link is invalid or has expired.', 400));
    }

    user.password = password;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save(); // pre('save') hashes password automatically

    createSendToken(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// 7. GOOGLE LOGIN
export const googleLogin = async (req: Request, res: Response, next: NextFunction) => {
  const { token, profile } = req.body;

  if (!token || !profile) {
    return next(new AppError('Google OAuth credentials are required', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    // Return mock Google Session
    const mockUser = {
      id: `google_${profile.id || Date.now()}`,
      name: profile.name || 'Google User',
      email: profile.email || 'googleuser@gmail.com',
      avatar: profile.picture || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      role: 'user',
      status: 'active',
      isVerified: true,
    };
    return createSendToken(mockUser, 200, res);
  }

  try {
    // Check if user with googleId exists
    let user = await User.findOne({ googleId: profile.id });

    if (!user) {
      // Check if user with same email exists
      user = await User.findOne({ email: profile.email });

      if (user) {
        // Link googleId to existing user
        user.googleId = profile.id;
        if (!user.avatar || user.avatar.includes('unsplash')) {
          user.avatar = profile.picture || user.avatar;
        }
        user.isVerified = true;
        await user.save({ validateBeforeSave: false });
      } else {
        // Create new user via Google
        const generatedPassword = crypto.randomBytes(16).toString('hex');
        user = await User.create({
          name: profile.name,
          email: profile.email,
          password: generatedPassword,
          googleId: profile.id,
          avatar: profile.picture || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
          isVerified: true,
        });
      }
    }

    if (user.status === 'suspended') {
      return next(new AppError('Your account has been suspended', 403));
    }

    createSendToken(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// 8. LOGOUT
export const logout = async (req: Request, res: Response) => {
  const currentUser = (req as any).user;

  if (mongoose.connection.readyState === 1 && currentUser) {
    // Clear refresh token in database
    await User.findByIdAndUpdate(currentUser._id || currentUser.id, {
      $unset: { refreshToken: 1 },
    });
  }

  res.cookie('token', 'loggedout', {
    expires: new Date(Date.now() + 5 * 1000),
    httpOnly: true,
  });

  res.cookie('refreshToken', 'loggedout', {
    expires: new Date(Date.now() + 5 * 1000),
    httpOnly: true,
    path: '/api/auth/refresh-token',
  });

  res.status(200).json({ status: 'success' });
};

// 9. GET PROFILE (ME)
export const getMe = (req: Request, res: Response) => {
  res.status(200).json({
    status: 'success',
    user: (req as any).user,
  });
};

// 10. UPDATE PROFILE
export const updateMe = async (req: Request, res: Response, next: NextFunction) => {
  const currentUser = (req as any).user;
  const { name, customStatus } = req.body;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      user: {
        ...currentUser,
        name: name || currentUser.name,
        customStatus: customStatus !== undefined ? customStatus : currentUser.customStatus,
      },
    });
  }

  try {
    const updatedUser = await User.findByIdAndUpdate(
      currentUser.id || currentUser._id,
      { name, customStatus },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      status: 'success',
      user: updatedUser,
    });
  } catch (error: any) {
    next(error);
  }
};

// 11. CHANGE PASSWORD
export const changePassword = async (req: Request, res: Response, next: NextFunction) => {
  const currentUser = (req as any).user;
  const { oldPassword, newPassword } = req.body;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: 'Password updated successfully (Mock Mode)',
    });
  }

  try {
    const user = await User.findById(currentUser._id || currentUser.id).select('+password');
    if (!user) {
      return next(new AppError('User not found', 404));
    }

    if (!(await (user as any).comparePassword(oldPassword))) {
      return next(new AppError('Your current password is correct', 401));
    }

    user.password = newPassword;
    await user.save();

    createSendToken(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// 12. AVATAR UPLOAD
export const uploadAvatar = async (req: Request, res: Response, next: NextFunction) => {
  const currentUser = (req as any).user;

  if (!req.file) {
    return next(new AppError('Please upload an image file.', 400));
  }

  try {
    // Upload image to Cloudinary (returns base64 URI fallback automatically if offline)
    const avatarUrl = await uploadImageToCloudinary(req.file.buffer, 'avatars', currentUser._id || currentUser.id);

    if (mongoose.connection.readyState !== 1) {
      return res.status(200).json({
        status: 'success',
        avatar: avatarUrl,
        user: {
          ...currentUser,
          avatar: avatarUrl,
        },
      });
    }

    const updatedUser = await User.findByIdAndUpdate(
      currentUser._id || currentUser.id,
      { avatar: avatarUrl },
      { new: true }
    );

    res.status(200).json({
      status: 'success',
      avatar: avatarUrl,
      user: updatedUser,
    });
  } catch (error) {
    next(error);
  }
};
