import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Channel } from '../models/Channel';
import { Message } from '../models/Message';
import { AppError } from '../utils/errorHandler';
import { uploadImageToCloudinary } from '../services/uploadService';

// Mock listings for DB Offline Mode
const mockChannels = [
  { id: 'c1', name: 'general', description: 'Company-wide announcements and work-based discussions', isPrivate: false, category: 'general', membersCount: 15 },
  { id: 'c2', name: 'engineering-team', description: 'Tech stack talks, PR reviews, and coding support', isPrivate: false, category: 'development', membersCount: 8 },
  { id: 'c3', name: 'marketing-campaigns', description: 'Planning the upcoming Q3 product release and ads', isPrivate: true, category: 'marketing', membersCount: 5 },
  { id: 'c4', name: 'watercooler', description: 'Coffee chats, jokes, memes, and random links', isPrivate: false, category: 'random', membersCount: 12 },
];

// 1. GET CHANNELS
export const getChannels = async (req: Request, res: Response, next: NextFunction) => {
  const { teamId } = req.query;

  if (mongoose.connection.readyState !== 1) {
    // If teamId is specified, we can filter mock channels or return all
    const filteredMock = teamId 
      ? mockChannels 
      : mockChannels;
    return res.status(200).json({
      status: 'success',
      channels: filteredMock,
    });
  }

  try {
    const query: any = {};
    if (teamId) {
      query.team = teamId;
    }
    const channels = await Channel.find(query);
    res.status(200).json({
      status: 'success',
      channels: channels.length > 0 ? channels : mockChannels,
    });
  } catch (error: any) {
    next(error);
  }
};

// 2. CREATE CHANNEL
export const createChannel = async (req: Request, res: Response, next: NextFunction) => {
  const { name, description, isPrivate, category, teamId } = req.body;

  if (!name) {
    return next(new AppError('Please provide a channel name', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    const mockChan = {
      id: `c_${Date.now()}`,
      name: name.toLowerCase().replace(/\s+/g, '-'),
      description,
      isPrivate: !!isPrivate,
      category: category || 'general',
      membersCount: 1,
      team: teamId,
    };
    return res.status(201).json({
      status: 'success',
      channel: mockChan,
    });
  }

  try {
    const newChannel = await Channel.create({
      name,
      description,
      isPrivate,
      category,
      team: teamId || undefined,
    });

    res.status(201).json({
      status: 'success',
      channel: newChannel,
    });
  } catch (error: any) {
    next(error);
  }
};

// 3. GET MESSAGES BY CHAT ID
export const getMessages = async (req: Request, res: Response, next: NextFunction) => {
  const { chatId } = req.params;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      messages: [],
    });
  }

  try {
    const messages = await Message.find({ chatId })
      .populate('sender', 'name avatar role')
      .populate('replies.sender', 'name avatar role')
      .sort({ createdAt: 1 });

    res.status(200).json({
      status: 'success',
      messages,
    });
  } catch (error: any) {
    next(error);
  }
};

// 4. EDIT MESSAGE
export const editMessage = async (req: Request, res: Response, next: NextFunction) => {
  const { messageId } = req.params;
  const { content } = req.body;

  if (!content) {
    return next(new AppError('Message content is required to edit', 400));
  }

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: {
        id: messageId,
        content,
        isEdited: true,
      },
    });
  }

  try {
    const message = await Message.findById(messageId);
    if (!message) {
      return next(new AppError('Message not found', 404));
    }

    // Check if sender is the one editing (req.user is set by authMiddleware)
    const currentUserId = (req as any).user._id || (req as any).user.id;
    if (message.sender.toString() !== currentUserId.toString()) {
      return next(new AppError('You do not have permission to edit this message', 403));
    }

    message.content = content;
    message.isEdited = true;
    await message.save();

    res.status(200).json({
      status: 'success',
      message,
    });
  } catch (error: any) {
    next(error);
  }
};

// 5. DELETE MESSAGE
export const deleteMessage = async (req: Request, res: Response, next: NextFunction) => {
  const { messageId } = req.params;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      messageId,
    });
  }

  try {
    const message = await Message.findById(messageId);
    if (!message) {
      return next(new AppError('Message not found', 404));
    }

    // Check if sender is the one deleting
    const currentUserId = (req as any).user._id || (req as any).user.id;
    if (message.sender.toString() !== currentUserId.toString()) {
      return next(new AppError('You do not have permission to delete this message', 403));
    }

    await Message.findByIdAndDelete(messageId);

    res.status(200).json({
      status: 'success',
      messageId,
    });
  } catch (error: any) {
    next(error);
  }
};

// 6. TOGGLE PIN MESSAGE
export const pinMessage = async (req: Request, res: Response, next: NextFunction) => {
  const { messageId } = req.params;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      message: {
        id: messageId,
        isPinned: true, // mock toggle
      },
    });
  }

  try {
    const message = await Message.findById(messageId);
    if (!message) {
      return next(new AppError('Message not found', 404));
    }

    message.isPinned = !message.isPinned;
    await message.save();

    res.status(200).json({
      status: 'success',
      message,
    });
  } catch (error: any) {
    next(error);
  }
};

// 7. FILE UPLOAD SHARING
export const uploadFile = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.file) {
    return next(new AppError('Please select a file to upload', 400));
  }

  try {
    const mimeType = req.file.mimetype;
    const originalName = req.file.originalname;
    const sizeInBytes = req.file.size;
    
    // Format size
    let fileSizeStr = `${(sizeInBytes / 1024).toFixed(1)} KB`;
    if (sizeInBytes > 1024 * 1024) {
      fileSizeStr = `${(sizeInBytes / (1024 * 1024)).toFixed(1)} MB`;
    }

    // Upload using standard Cloudinary buffer upload (with base64 fallback)
    const fileUrl = await uploadImageToCloudinary(req.file.buffer, 'chat_files', originalName);

    res.status(200).json({
      status: 'success',
      file: {
        fileUrl,
        fileName: originalName,
        fileSize: fileSizeStr,
        mimeType,
      },
    });
  } catch (error) {
    next(error);
  }
};
