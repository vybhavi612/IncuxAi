import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Meeting } from '../models/Meeting';
import { Team } from '../models/Team';
import { Channel } from '../models/Channel';
import { Notification } from '../models/Notification';
import { User } from '../models/User';

// Mock values for MongoDB Offline Mode
const mockStats = {
  activeTeamsCount: 3,
  totalChannelsCount: 8,
  onlineColleaguesCount: 5,
  upcomingMeetingsCount: 2,
};

const mockUpcomingMeetings = [
  {
    id: 'm1',
    title: 'Daily Standup Sync',
    roomId: 'meet-daily-standup',
    type: 'scheduled',
    scheduledAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // in 4 hours
    duration: 30,
    host: { id: 'u2', name: 'Sarah Connor', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150' },
  },
  {
    id: 'm2',
    title: 'Product Roadmap Q3 Review',
    roomId: 'meet-q3-roadmap',
    type: 'scheduled',
    scheduledAt: new Date(Date.now() + 26 * 60 * 60 * 1000).toISOString(), // tomorrow
    duration: 60,
    host: { id: 'u3', name: 'John Doe', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150' },
  },
];

const mockRecentMeetings = [
  {
    id: 'm3',
    title: 'Code Refactoring Session',
    roomId: 'meet-refactor-session',
    type: 'instant',
    scheduledAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    duration: 45,
    host: { id: 'u1', name: 'You' },
  },
  {
    id: 'm4',
    title: 'Weekly Alignment Call',
    roomId: 'meet-weekly-alignment',
    type: 'scheduled',
    scheduledAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    duration: 30,
    host: { id: 'u4', name: 'Alex Murphy' },
  },
];

const mockNotifications = [
  {
    id: 'n1',
    type: 'mention',
    content: 'Sarah Connor mentioned you in #general channel',
    isRead: false,
    link: '/chat',
    createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 mins ago
  },
  {
    id: 'n2',
    type: 'meeting',
    content: 'John Doe invited you to "Product Roadmap Q3 Review"',
    isRead: false,
    link: '/?join=meet-q3-roadmap',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
  },
  {
    id: 'n3',
    type: 'team',
    content: 'You were added to the Engineering Team workspace',
    isRead: true,
    link: '/chat',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
  },
];

export const getDashboardData = async (req: Request, res: Response, next: NextFunction) => {
  const currentUser = (req as any).user;

  if (mongoose.connection.readyState !== 1) {
    return res.status(200).json({
      status: 'success',
      stats: mockStats,
      upcomingMeetings: mockUpcomingMeetings,
      recentMeetings: mockRecentMeetings,
      notifications: mockNotifications,
    });
  }

  try {
    // 1. Gather stats
    const activeTeamsCount = await Team.countDocuments({
      'members.user': currentUser._id || currentUser.id,
    });

    const totalChannelsCount = await Channel.countDocuments();

    // Query active online colleagues (users with status active)
    const onlineColleaguesCount = await User.countDocuments({
      status: 'active',
      _id: { $ne: currentUser._id || currentUser.id },
    });

    // 2. Fetch upcoming meetings (scheduled, time is in future)
    const upcomingMeetings = await Meeting.find({
      status: 'scheduled',
      scheduledAt: { $gte: new Date() },
      $or: [
        { host: currentUser._id || currentUser.id },
        { participants: currentUser._id || currentUser.id }
      ]
    })
      .populate('host', 'name email avatar')
      .sort({ scheduledAt: 1 })
      .limit(5);

    // 3. Fetch past meetings (completed, or elapsed scheduled meetings)
    const recentMeetings = await Meeting.find({
      $and: [
        {
          $or: [
            { status: 'completed' },
            { scheduledAt: { $lt: new Date() } }
          ]
        },
        {
          $or: [
            { host: currentUser._id || currentUser.id },
            { participants: currentUser._id || currentUser.id }
          ]
        }
      ]
    })
      .populate('host', 'name email avatar')
      .sort({ scheduledAt: -1 })
      .limit(5);

    // 4. Fetch notifications
    const notifications = await Notification.find({
      recipient: currentUser._id || currentUser.id,
    })
      .populate('sender', 'name avatar')
      .sort({ createdAt: -1 })
      .limit(10);

    // Compile actual stats
    const stats = {
      activeTeamsCount: activeTeamsCount || mockStats.activeTeamsCount,
      totalChannelsCount: totalChannelsCount || mockStats.totalChannelsCount,
      onlineColleaguesCount: onlineColleaguesCount || mockStats.onlineColleaguesCount,
      upcomingMeetingsCount: upcomingMeetings.length,
    };

    res.status(200).json({
      status: 'success',
      stats,
      upcomingMeetings: upcomingMeetings.length > 0 ? upcomingMeetings : mockUpcomingMeetings,
      recentMeetings: recentMeetings.length > 0 ? recentMeetings : mockRecentMeetings,
      notifications: notifications.length > 0 ? notifications : mockNotifications,
    });
  } catch (error) {
    next(error);
  }
};
