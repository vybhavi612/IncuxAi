import { Request, Response, NextFunction } from 'express';
import Meeting from '../models/Meeting';
import { AppError } from '../utils/errorHandler';

// Get all meetings (scheduled or active) for the logged in user
export const getMyCalendarMeetings = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = (req as any).user?.id || (req as any).user?._id;
    if (!userId) {
      return next(new AppError('You must be logged in to access the calendar', 401));
    }

    // Find meetings where user is host or participant
    const meetings = await Meeting.find({
      $or: [{ host: userId }, { participants: userId }],
    })
      .populate('host', 'name email avatar')
      .populate('participants', 'name email avatar')
      .sort({ scheduledAt: 1 });

    res.status(200).json({
      status: 'success',
      results: meetings.length,
      meetings,
    });
  } catch (error) {
    next(error);
  }
};

// Schedule a new meeting on the calendar
export const createCalendarMeeting = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { title, roomId, scheduledAt, duration, participants } = req.body;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in to schedule a meeting', 401));
    }

    if (!title || !roomId || !scheduledAt) {
      return next(new AppError('Meeting title, room ID, and schedule time are required', 400));
    }

    // Check if roomId is unique
    const existing = await Meeting.findOne({ roomId });
    if (existing) {
      return next(new AppError('A meeting room with this ID already exists', 400));
    }

    const meeting = await Meeting.create({
      title,
      roomId,
      host: userId,
      type: 'scheduled',
      scheduledAt: new Date(scheduledAt),
      duration: duration || 30,
      status: 'scheduled',
      participants: participants || [],
    });

    const populatedMeeting = await Meeting.findById(meeting._id)
      .populate('host', 'name email avatar')
      .populate('participants', 'name email avatar');

    res.status(201).json({
      status: 'success',
      meeting: populatedMeeting,
    });
  } catch (error) {
    next(error);
  }
};

// Cancel/Delete meeting
export const deleteCalendarMeeting = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || (req as any).user?._id;

    if (!userId) {
      return next(new AppError('You must be logged in', 401));
    }

    const meeting = await Meeting.findById(id);
    if (!meeting) {
      return next(new AppError('Meeting not found', 404));
    }

    // Only host can delete the meeting
    if (meeting.host.toString() !== userId.toString()) {
      return next(new AppError('Only the meeting host can cancel this meeting', 403));
    }

    await Meeting.findByIdAndDelete(id);

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    next(error);
  }
};
