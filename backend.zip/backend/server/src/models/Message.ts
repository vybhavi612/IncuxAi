import { Schema, model } from 'mongoose';

const replySchema = new Schema(
  {
    sender: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const messageSchema = new Schema(
  {
    chatId: {
      type: String,
      required: [true, 'Please provide a chatId (channel ID or DM ID)'],
      index: true,
    },
    sender: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    content: {
      type: String,
      required: [true, 'Please provide message content'],
    },
    type: {
      type: String,
      enum: ['text', 'code', 'file'],
      default: 'text',
    },
    codeLanguage: {
      type: String,
    },
    codeSnippet: {
      type: String,
    },
    fileUrl: {
      type: String,
    },
    fileName: {
      type: String,
    },
    fileSize: {
      type: String,
    },
    reactions: [
      {
        emoji: String,
        count: { type: Number, default: 1 },
        users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
      },
    ],
    isEdited: {
      type: Boolean,
      default: false,
    },
    isPinned: {
      type: Boolean,
      default: false,
    },
    isRead: {
      type: Boolean,
      default: false,
    },
    isDelivered: {
      type: Boolean,
      default: true,
    },
    mimeType: String,
    replies: [replySchema],
  },
  {
    timestamps: true,
  }
);

export const Message = model('Message', messageSchema);
export default Message;
