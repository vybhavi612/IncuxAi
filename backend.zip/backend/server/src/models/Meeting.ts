import { Schema, model } from 'mongoose';

const meetingSchema = new Schema(
  {
    title: {
      type: String,
      required: [true, 'Please provide a meeting title'],
      trim: true,
    },
    roomId: {
      type: String,
      required: [true, 'Please provide a room ID'],
      unique: true,
      index: true,
    },
    host: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: {
      type: String,
      enum: ['instant', 'scheduled'],
      default: 'instant',
    },
    scheduledAt: {
      type: Date,
      default: Date.now,
    },
    duration: {
      type: Number, // in minutes
      default: 30,
    },
    status: {
      type: String,
      enum: ['scheduled', 'active', 'completed'],
      default: 'scheduled',
    },
    participants: [
      {
        type: Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
  },
  {
    timestamps: true,
  }
);

export const Meeting = model('Meeting', meetingSchema);
export default Meeting;
