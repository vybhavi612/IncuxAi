import { Schema, model } from 'mongoose';

const teamMemberSchema = new Schema(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    role: {
      type: String,
      enum: ['owner', 'admin', 'member'],
      default: 'member',
    },
  },
  {
    _id: false,
  }
);

const teamSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide a team name'],
      unique: true,
      trim: true,
    },
    description: {
      type: String,
      default: '',
    },
    members: [teamMemberSchema],
  },
  {
    timestamps: true,
  }
);

export const Team = model('Team', teamSchema);
export default Team;
