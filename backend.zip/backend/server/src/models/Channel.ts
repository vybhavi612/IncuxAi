import { Schema, model } from 'mongoose';

const channelSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide a channel name'],
      unique: true,
      trim: true,
      lowercase: true,
    },
    description: {
      type: String,
      default: '',
    },
    isPrivate: {
      type: Boolean,
      default: false,
    },
    category: {
      type: String,
      enum: ['general', 'marketing', 'development', 'random'],
      default: 'general',
    },
    membersCount: {
      type: Number,
      default: 1,
    },
    team: {
      type: Schema.Types.ObjectId,
      ref: 'Team',
    },
  },
  {
    timestamps: true,
  }
);

export const Channel = model('Channel', channelSchema);
export default Channel;
